﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;
using Entalyan.EntIRC.Events;
using Entalyan.EntIRC.IRCProtocol;


namespace Entalyan.EntIRC
{
    /// <summary>
    /// This class provides access to an IRC server. It provides methods
    /// to manage a connection, send and receive data, and exposes received
    /// data for consumption.
    /// </summary>
    public class IrcClient
    {
        #region Constants

        private const string ENCODING = "UTF-8";

        #endregion

        #region Private Fields

        private TcpClient networkClient;
        //private StreamReader readBuffer;
        //private StreamWriter writeBuffer;

        private IList<string> messageBuffer;


        #endregion

        #region Properties


        /// <summary>
        /// Retrieves the full list of received messages.
        /// </summary>
        public IList<string> Messages
        {
            get
            {
                return messageBuffer;
            }
            internal set
            {
                messageBuffer = value;
            }
        }

        /// <summary>
        /// Gets the encoding used on all messages.
        /// </summary>
        internal static Encoding Encoding { get { return Encoding.GetEncoding(ENCODING); } }

        /// <summary>
        /// Gets a value indicating if the IRC client is currently connected to a server.
        /// </summary>
        public bool Connected
        {
            get
            {
                return networkClient.Connected;
            }
        }

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="IrcClient"/> class.
        /// </summary>
        public IrcClient()
        {
            Messages = new List<string>();
            networkClient = new TcpClient();

            //connection = new IrcConnection();
            //connection.RawMessageReceived += OnMessageReceived;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// This method will connect to the IRC server using the connection
        /// information specified for this user. When connected the listener
        /// loop will start in order for messages to pass in from the server
        /// to the client.
        /// </summary>
        /// <param name="user">The IrcUser that will log in to the server.</param>
        /// <returns></returns>
        public async Task ConnectAsync(IrcUser user)
        {
            //This method will handle connecting to the IRC server, and starting
            //and maintaining the listener. T
            Task ConnectionStarterTask = Task.Run(() => ConnectToServer(user));
            Task ListenerStarterTask = await ConnectionStarterTask.ContinueWith(async (connect) =>
            {
                await RunListener(networkClient.GetStream());
            }, TaskContinuationOptions.LongRunning
            );

        }

        /// <summary>
        /// Sends the sequence of messages to the server required for authentication.
        /// </summary>
        /// <param name="user">The IrcUser that will log in to the server.</param>
        /// <returns></returns>
        //public async Task LogOn(IrcUser user)
        //{
        //Create and send the messages required to authenticate with the server
        //await connection.WriteAsync(new IrcMessage(null, "PASS", user.Password));
        //await connection.WriteAsync(new IrcMessage(null, "NICK", user.Nickname));
        //await connection.WriteAsync(new IrcMessage(null, "USER", user.UserName, "8", "*", user.RealName));

        //}
        #endregion

        #region Private Methods

        /// <summary>
        /// Connects to the specified IRC server. 
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        private async Task ConnectToServer(IrcUser user)
        {
            //ConnectionStarterTask to the server
            await networkClient.ConnectAsync(user.HostAddress, user.HostPort).ContinueWith(connect =>
            {
                //If connection was not succesful throw exception(s).
                throw connect.Exception.Flatten();
            }, TaskContinuationOptions.OnlyOnFaulted
                );
        }

        /// <summary>
        /// This starts the listener. This enables the client to receive messages from the server. These
        /// messages are put on a seperate thread and handled by the most appropriate handler.
        /// </summary>
        /// <returns></returns>
        private async Task RunListener(NetworkStream targetStream)
        {
            var readBuffer = new StreamReader(targetStream, IrcClient.Encoding);

            while (this.Connected)
            {
                //Receive a line of data from the IRC server
                await readBuffer.ReadLineAsync().ContinueWith(async (readMessage) =>
                {
                    //Start handling of the received message in another thread so
                    //the listener can keep running.
                    await Task.Run(async () =>
                    {
                        IrcMessage parsedMessage = ParseIrcMessage(await readMessage);

                        //TODO: Improve routing mechanism.
                        OnMessageReceived(new MessageEventArgs(parsedMessage));

                    }
                    );
                }
                );
            }
        }

        /// <summary>
        /// Listens for incoming data on the IRC server connection. Passes all messages asynchronously to 
        /// their handler.
        /// </summary>
        /// <returns></returns>
        private static IrcMessage ParseIrcMessage(string rawMessage)
        {
            var ircMsg = new IrcMessage();
            ircMsg.Message = rawMessage;

            //If first character of the first word is a colon, this message has a prefix.
            if (rawMessage.Substring(0, 1) == ":")
            {
                ircMsg.Prefix = rawMessage.Substring(1, rawMessage.IndexOf(' ') - 1);
                rawMessage = rawMessage.Substring(rawMessage.IndexOf(' ') + 1);
            }

            ircMsg.Command = rawMessage.Substring(0, rawMessage.IndexOf(' '));
            rawMessage = rawMessage.Substring(rawMessage.IndexOf(' ') + 1);

            //The message now only has parameters left. Normal parameters are split by SPACE, and a last parameter
            //that is prefixed by COLON that can contain spaces. First the remaining raw message is split into two
            //parts, before and after the COLON (if present). Everything before the colon will be split at SPACE
            //and treated as seperate parameters. Everything after the COLON will be treated as a single parameter,
            //if it exists at all.
            var remainder = rawMessage.Split(new[] { ":" }, 2, StringSplitOptions.RemoveEmptyEntries);

            ircMsg.Parameters.AddRange(remainder[0].Split(' ')
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                );

            if (remainder.Length == 2)
            {
                ircMsg.Parameters.Add(remainder[1]);
            }

            return ircMsg;

        }

        #endregion


        #region Events

        /// <summary>
        /// This event is raised whenever a message is received from the IRC server.
        /// </summary>
        public event EventHandler<MessageEventArgs> MessageReceived;

        #endregion

        #region Event Handlers

        /// <summary>
        /// When a raw message is received by the connection this event is raised.
        /// </summary>
        protected virtual void OnMessageReceived(MessageEventArgs e)
        {
            EventHandler<MessageEventArgs> handler = MessageReceived;

            if (handler!= null)
                handler(this, e);
            
        }

        #endregion

    }


}
