﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

namespace Entalyan.EntIRC.IRCProtocol
{
    /// <summary>
    /// Represents a message that is used to communicate with an IRC server. Includes methods 
    /// for parsing raw strings into the different items that a message can contain.
    /// </summary>
    public class IrcMessage
    {
        
        #region Properties

        
        /// <summary>
        /// The optional prefix in an IRC message.
        /// </summary>
        internal string Prefix { get; set; }

        /// <summary>
        /// An IRC command.
        /// </summary>
        internal string Command { get; set; }

        /// <summary>
        /// All parameters that are passed to the server.
        /// </summary>
        internal List<string> Parameters { get; set; }

        public string Message { get;  set; }

        #endregion

        #region Constructors
        /// <summary>
        /// Creates a new IrcMessage, containing the commands and messages that go 
        /// to and from the IRC server.
        /// </summary>
        public IrcMessage()
        {
            this.Parameters = new List<string>();
        }

        /// <summary>
        /// Creates a new IrcMessage, containing the commands and messages that go 
        /// to and from the IRC server.
        /// </summary>
        public IrcMessage(string prefix, string command, params string[] parameters)
        {
            this.Prefix = prefix;
            this.Command = command;
            this.Parameters = new List<string>();

            foreach (string parameter in parameters)
            {
                this.Parameters.Add(parameter);
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Build a raw data string based on the provided parameters.
        /// </summary>
        /// <returns></returns>
        public byte[] GetRawMessage()
        {
            var sb = new StringBuilder();

            //Prefix is optional
            if (this.Prefix != null)
            {
                sb.AppendFormat(":{0} ", this.Prefix);
            }

            //Command is required.
            if (this.Command != null)
            {
                sb.AppendFormat("{0}", this.Command);
            }
            else
            {
                throw new InvalidOperationException("Cannot parse a raw message without command argument.");
            }

            //Append all parameters with a space prefixed. This will seperate them
            //from the command, and each other.
            foreach (string param in this.Parameters)
            {
                sb.AppendFormat(" {0}", param);
            }

            //Insert terminator string to signify end of message
            sb.Append("\r\n");

            //Convert to a byte array for output
            var result = sb.ToString();
            return IrcClient.Encoding.GetBytes(result);
        }

        /* IRC Data Syntax:
         * 
         * <message>  ::= [':' <prefix> <SPACE> ] <command> <params> <crlf>
         * <prefix>   ::= <servername> | <nick> [ '!' <user> ] [ '@' <host> ]
         * <command>  ::= <letter> { <letter> } | <number> <number> <number>
         * <SPACE>    ::= ' ' { ' ' }
         * <params>   ::= <SPACE> [ ':' <trailing> | <middle> <params> ]
         * <middle>   ::= <Any *non-empty* sequence of octets not including SPACE
         *                or NUL or CR or LF, the first of which may not be ':'>
         * <trailing> ::= <Any, possibly *empty*, sequence of octets not including
         *                NUL or CR or LF>
         * <crlf>     ::= CR LF
         * SPACE = %x20 ; Whitespace. 
         * crlf = %x0D %x0A ; Carriage return/linefeed. 
         */
        /// <summary>
        /// Parses a raw message string into a usable format.
        /// </summary>
        /// <param name="rawMessage">A string in raw IRC format.</param>
        /// <returns>A structured object contining the information that was in the message before.</returns>
        /// <remarks>The way this string is parsed, is by identifying an element at the front of the array,
        /// moving that to its correct position, then removing it from the original string. This way we know
        /// we always only need to process the first entry, and we have a way of telling when we're done.
        /// </remarks>
        public static IrcMessage ParseRawToClean(byte[] rawMessage)
        {
            var ircMsg = new IrcMessage();
            ircMsg.Message = IrcClient.Encoding.GetString(rawMessage);

            //Make a working copy of the full message for parsing.
            var raw = ircMsg.Message;
            
            //If first character of the first word is a colon, this message has a prefix.
            if (raw.Substring(0, 1) == ":")
            {
                ircMsg.Prefix = raw.Substring(1, raw.IndexOf(' ') - 1);
                raw = raw.Substring(raw.IndexOf(' ') + 1);
            }

            ircMsg.Command = raw.Substring(0, raw.IndexOf(' '));
            raw = raw.Substring(raw.IndexOf(' ') + 1);

            //The message now only has parameters left. Normal parameters are split by SPACE, and a last parameter
            //that is prefixed by COLON that can contain spaces. First the remaining raw message is split into two
            //parts, before and after the COLON (if present). Everything before the colon will be split at SPACE
            //and treated as seperate parameters. Everything after the COLON will be treated as a single parameter,
            //if it exists at all.
            var remainder = raw.Split(new[] { ":" }, 2, StringSplitOptions.RemoveEmptyEntries);

            ircMsg.Parameters.AddRange(remainder[0].Split(' ')
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                );       
     
            if (remainder.Length == 2)
            {
                ircMsg.Parameters.Add(remainder[1]);
            }

            return ircMsg;

        }

        #endregion
    }
}
