﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entalyan.EntIRC.IRCProtocol;

namespace Entalyan.EntIRC.Events
{
    /// <summary>
    /// EventArgs-class used when a new message is received.
    /// </summary>
    public class MessageEventArgs : EventArgs
    {

        private IrcMessage messageData;

        /// <summary>
        /// Retrieves all data contained in the message.
        /// </summary>
        public IrcMessage Data
        {
            get { return messageData; }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MessageEventArgs"/> class.
        /// </summary>
        public MessageEventArgs(IrcMessage message)
        {
            this.messageData = message; 
        }

    }
}
